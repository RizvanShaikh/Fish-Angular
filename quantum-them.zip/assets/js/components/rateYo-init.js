(function(window, document, $, undefined) {
    "use strict";
  $(function() {
    $("#product-id_10").rateYo({
      rating: 2.5,
      "starWidth": "20px",
      "normalFill":QuantumPro.APP_COLORS.grey200,
      "ratedFill": QuantumPro.APP_COLORS.primary
    });
    $("#product-id_25").rateYo({
      rating: 3.5,
      "starWidth": "20px",
      "normalFill":QuantumPro.APP_COLORS.grey200,
      "ratedFill": QuantumPro.APP_COLORS.primary
    });
    $("#product-id_57").rateYo({
      rating: 4.6,
      "starWidth": "20px",
      "normalFill":QuantumPro.APP_COLORS.grey200,
      "ratedFill": QuantumPro.APP_COLORS.primary
    });
    $("#product-id_42").rateYo({
      rating: 2.3,
      "starWidth": "20px",
      "normalFill":QuantumPro.APP_COLORS.grey200,
      "ratedFill": QuantumPro.APP_COLORS.primary
    });


    $("#product-id_38").rateYo({
      rating: 2.6,
      "starWidth": "20px",
      "normalFill":QuantumPro.APP_COLORS.grey200,
      "ratedFill": QuantumPro.APP_COLORS.primary
    });

    $("#product-id_32").rateYo({
      rating: 1.3,
      "starWidth": "20px",
      "normalFill":QuantumPro.APP_COLORS.grey200,
      "ratedFill": QuantumPro.APP_COLORS.primary
    });
    $("#product-id_100").rateYo({
      rating: 4.5,
      "starWidth": "20px",
      "normalFill":QuantumPro.APP_COLORS.grey200,
      "ratedFill": QuantumPro.APP_COLORS.primary
    });
    $("#product-id_101").rateYo({
      rating: 3.3,
      "starWidth": "20px",
      "normalFill":QuantumPro.APP_COLORS.grey200,
      "ratedFill": QuantumPro.APP_COLORS.primary
    });
    $("#product-id_102").rateYo({
      rating: 4.0,
      "starWidth": "20px",
      "normalFill":QuantumPro.APP_COLORS.grey200,
      "ratedFill": QuantumPro.APP_COLORS.primary
    });
    $("#product-id_103").rateYo({
      rating: 2.5,
      "starWidth": "20px",
      "normalFill":QuantumPro.APP_COLORS.grey200,
      "ratedFill": QuantumPro.APP_COLORS.primary
    });
    $("#product-id_104").rateYo({
      rating: 2.0,
      "starWidth": "20px",
      "normalFill":QuantumPro.APP_COLORS.grey200,
      "ratedFill": QuantumPro.APP_COLORS.primary
    });
    $("#product-id_11").rateYo({
      rating: 3.3,
      "starWidth": "20px",
      "normalFill":QuantumPro.APP_COLORS.grey200,
      "ratedFill": QuantumPro.APP_COLORS.primary
    });

    $("#product-id_65").rateYo({
      rating: 4.0,
      "starWidth": "20px",
      "normalFill":QuantumPro.APP_COLORS.grey200,
      "ratedFill": QuantumPro.APP_COLORS.primary
    });
    $("#product-id_26").rateYo({
      rating: 4.5,
      "starWidth": "20px",
      "normalFill":QuantumPro.APP_COLORS.grey200,
      "ratedFill": QuantumPro.APP_COLORS.primary
    });
    $("#product-id_27").rateYo({
      rating: 1.5,
      "starWidth": "20px",
      "normalFill":QuantumPro.APP_COLORS.grey200,
      "ratedFill": QuantumPro.APP_COLORS.primary
    });
    $("#product-id_28").rateYo({
      rating: 2.8,
      "starWidth": "20px",
      "normalFill":QuantumPro.APP_COLORS.grey200,
      "ratedFill": QuantumPro.APP_COLORS.primary
    });
    $("#product-id_180").rateYo({
      rating: 3.6,
      "starWidth": "20px",
      "normalFill":QuantumPro.APP_COLORS.grey200,
      "ratedFill": QuantumPro.APP_COLORS.primary
    });
  });
})(window, document, window.jQuery);
